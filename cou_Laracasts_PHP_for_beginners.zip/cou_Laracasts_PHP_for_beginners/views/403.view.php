<?php require base_path('views/partials/head.php'); ?>
  <?php require base_path('views/partials/nav.php'); ?>

  <?php require base_path('views/partials/banner.php'); ?>
  <main>
  <div class="mx-auto max-w-7xl py-6 sm:px-6 lg:px-8">
  <h1 class="text-2xl font-bold">Forbidden.</h1>
  <p class="mt-4">
    <a href="#" class="text-blue underline">Go back home.</a>
  </p>
</div>

  </main>
  <?php require base_path('views/partials/footer.php'); ?>