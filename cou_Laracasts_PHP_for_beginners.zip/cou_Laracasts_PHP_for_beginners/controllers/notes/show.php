<?php

use Core\Database;

$config = require base_path('config.php');


$db = new Database($config['database']);
$curentUserId = 1;

$note =$db->query('SELECT * FROM notes WHERE id = :id',[
    'id' => $_GET['id']
])->findOrFail();


authorize($note['user_id'] === $curentUserId);



view("notes/show",[
    "heading" => "Note",
    "note" => $note,
]);
